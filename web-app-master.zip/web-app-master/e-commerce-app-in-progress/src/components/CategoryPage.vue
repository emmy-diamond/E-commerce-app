<template>
   <div>
      <ProductCardPanel 
         v-bind:title="'Category: ' + $route.params.categoryAlias"
         v-bind:categoryAlias="$route.params.categoryAlias">
      </ProductCardPanel>
   </div>
</template>

<script>
import ProductCardPanel from './ProductCardPanel.vue'

export default {
  name: 'CategoryPage',
  components: {
    ProductCardPanel,
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
