<template>
    <div>
      <h1>Cart</h1>


<table class="table table-striped table-hover" v-if="products.length">
<thead>
    <th>Product</th>
    <th>Product option</th>
    <th>Price</th>
    <th>Quantity</th>
    <th>Total</th>
</thead>
<tbody>
    <tr v-for="item in (this.$root.$data.cart.items || [])" :key="item">
        <td>{{productById(item.productId).title}}</td>
        <td>{{item.optionCode}}</td>
        <td>{{item.price}}</td>
        <td>{{item.qnt}}</td>
        <td>{{item.total}}</td>

    </tr>
</tbody>
</table>


    </div>
</template>

<script>
import axios from 'axios'
export default {
    name: 'CartPage',
    mounted(){
        axios
      .get("https://euas.person.ee/products/")
      .then (response => {
          this.products = response.data;
      })

    },
    data: function(){
        return {
            products:[]
        }
    },
    methods: {
        productById(productId){
            return this.products.find(product => product.id == productId)
        }
    }
    
}
</script>
<style scoped>

</style>