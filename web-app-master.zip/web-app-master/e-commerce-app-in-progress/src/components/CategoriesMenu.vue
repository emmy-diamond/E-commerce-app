<template>
   <div>
   <h5>Categories</h5>
    <b-nav vertical>
      <template v-for="category in categories">
        <b-nav-item v-bind:to="'/categories/' + category.alias" v-bind:key="category.alias"
          exact exact-active-class="active">{{category.title}}</b-nav-item>
      </template>
    </b-nav>
   </div>
</template>

<script>
import axios from "axios";

export default {
  name: 'CategoriesMenu',
  data: function() {
    return {
      categories: []
    }
  },
  mounted() {
    axios
      .get("https://euas.person.ee/categories")
      .then(response => {
        this.categories = response.data;
      })
      .catch(err => {
        console.log(err);
      });
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
