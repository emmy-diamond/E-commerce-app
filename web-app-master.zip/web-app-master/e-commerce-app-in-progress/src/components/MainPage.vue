<template>
   <div>
      <ProductCardPanel title="Top selling products" tag="topselling"/>
      <ProductCardPanel title="Recommended" tag="recommended" />
      <ProductCardPanel title="Buy now!" tag="buynow"/>
   </div>
</template>

<script>
import ProductCardPanel from './ProductCardPanel.vue'

export default {
  name: 'MainPage',
  components: {
    ProductCardPanel
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
