<template>
      <b-row>
        <b-col sm="12">
          <h3>{{title}}</h3>
          <b-card-group deck>
            <template v-for="product in products">
              <ProductCard v-bind:productParam="product" v-bind:key="product.id"/>
            </template>
          </b-card-group>
        </b-col>
      </b-row>
</template>

<script>
import ProductCard from './ProductCard.vue'
import axios from "axios";

export default {
  name: 'ProductCardPanel',

  components: {
    ProductCard
  },

  props: {
    title: String,
    tag: String,
    categoryAlias: String,
  },

  data() {
    return {
      products: []
    };
  },

  mounted() {
    if(this.tag) {
      axios
        .get("https://euas.person.ee/products/tags/" + this.tag)
        .then(response => {
          this.products = response.data;
        })
        .catch(err => {
          console.log(err);
        });
    } else if(this.categoryAlias) {
      axios
        .get("https://euas.person.ee/categories/" + this.categoryAlias + "/products")
        .then(response => {
          this.products = response.data;
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
