<template>
   <div>
      <h1>Product details for {{this.product.title}}</h1>
      <b-row>
         <b-col sm="5">
            <img v-bind:src="this.selectedOption.image">
         </b-col>
         <b-col sm="5">
            <h3>Price</h3>
            <p>${{this.selectedOption.price}}</p>
            <h3>Options</h3>
            <p>
                <b-button-group>
                  <b-button v-for="option in product.options" 
                     v-bind:key="option.code"
                     v-bind:pressed="option.code == selectedOption.code"
                     v-on:click="selectOption(option)"
                     >{{option.title}}</b-button>
               </b-button-group>
            </p>
            <h3>Quantity</h3>
            <p>
               <b-alert variant="danger" :show="this.qty > this.selectedOption.qty">There are only {{this.selectedOption.qty}} items available</b-alert>
               <b-input-group class="mt-1">
                  <b-input-group-prepend>
                     <b-button variant="info" v-on:click="remove">-</b-button>
                  </b-input-group-prepend>
                  <b-form-input v-model="qty"></b-form-input>
                  <b-input-group-append>
                     <b-button variant="info" v-on:click="add">+</b-button>
                  </b-input-group-append>
               </b-input-group>
               (available {{this.selectedOption.qty}})
            </p>
            <p>
               <b-button variant="secondary" @click="addToCart">Add to cart</b-button>
              <b-button class="ml-3" variant="success" @click="buyNow">Buy now!</b-button>

            </p>
         </b-col>
         <b-col sm="2">3 col</b-col>
      </b-row>
   </div>
</template>

<script>
import axios from "axios";

export default {
  name: 'Product',
  data: function() {
    return {
      product: {},
      selectedOption: {},
      qty: 1,
    }
  },
  
  methods: {
    selectOption: function (option) {
      this.selectedOption = option;
    },
    add: function () {
      this.qty++;
      //this.$root.$data.cart.items = this.qty;
      //this.$root.$data.saveCart();
    },
    remove: function () {
      if(this.qty < 2) return;
      this.qty--;
    },
 addToCart(){
  //  let items = this.$root.$data.cart.items || []
// if it is not empty
    if(!this.$root.$data.cart.items){
this.$root.$data.cart.items = [];
    } 

    this.$root.$data.cart.items.push({
      productId: this.product.id,
      qty: this.qty,
      optionCode: this.selectedOption.code,
      price: this.selectedOption.price,
      total: this.selectedOption.price * this.qty,
    })

this.$root.$data.saveCart();
    
  },
buyNow(){
this.addToCart(),
this.$router.push('/cart')
}
  },
  mounted() {
    axios
      .get("https://euas.person.ee/products/" + this.$route.params.productId)
      .then(response => {
        this.product = response.data;
        this.selectedOption = this.product.options[0];
      })
      .catch(err => {
        console.log(err);
      });
  }
 




}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
