<template>
  <b-card
    v-bind:title="productParam.title"
    v-bind:img-src="productParam.image"
    img-alt="Image"
    img-top
    tag="article"
    style="max-width: 20rem;"
    class="mb-2"
  >
    <b-card-text>
      {{productParam.description}}
    </b-card-text>

    <b-button v-bind:to="'/products/' + productParam.id" variant="primary">
      Details
    </b-button>
  </b-card>
</template>

<script>
export default {
  name: 'ProductCard',

  props: {
    productParam: Object
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
