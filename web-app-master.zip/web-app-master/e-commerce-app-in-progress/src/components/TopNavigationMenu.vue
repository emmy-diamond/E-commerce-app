<template>
    <b-nav>
        <b-nav-item to="/">Home</b-nav-item>
        <b-nav-item to="/about-us">About</b-nav-item>
        <b-nav-item to="/cart">Cart  ({{this.$root.$data.cart.items ? this.$root.$data.cart.items.length :0 }})</b-nav-item>
    </b-nav>
</template>

<script>
export default {
  name: 'TopNavigationMenu',
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
