<template>
  <div id="app">
    <b-container class="bv-example-row">
      <b-row>
        <b-col sm="12">
          <TopNavigationMenu/>
        </b-col>
      </b-row>
      
      <b-row>
        <b-col sm="2"><CategoriesMenu/></b-col>
        <b-col sm="10">
          <router-view :key="$route.fullPath"></router-view>
        </b-col>
       
      </b-row>
    </b-container>
  </div>
</template>

<script>
import TopNavigationMenu from './components/TopNavigationMenu.vue'
import CategoriesMenu from './components/CategoriesMenu.vue'


export default {
  name: 'app',
  components: {
    TopNavigationMenu,
    CategoriesMenu
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
